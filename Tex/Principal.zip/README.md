# TCC-IFES
Tex TCC-IFES Repository

## Folders

1. Analyses

Contains source code to analyse NERI results.

2. Generated-Images

Contains graph imagens generateds by analyse program.

3. Tex

Contains TeX project files

## Author

1. João Carlos Pandolfi Santana

## Contact

1. joaopandolfi@gmail.com